import * as React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import loginimg from "../assets/images/loginimg.png";
import "../App.css";
import { Link } from "react-router-dom";
const Login = () => {
  return (
    <>
      {/* MAin Container of Register Page */}
      <div className="container-fluid w-100 vh-100">
        <div className="row vh-100">
          {/* Left side For Image */}
          <div className="img-container col-sm-12 col-md-6">
            <img src={loginimg} alt="" />
          </div>
          {/* Form, Right Side */}
          <div className="form-container  col-sm-12 col-md-6">
            <div className="heading-form">
              <h1 className="form-h1">Login</h1>
              {/* <h4 className="form-h4">Please fill the below cridential</h4> */}
            </div>
            <div className="form-inputs">
              <Box
                component="form"
                sx={{ "& > :not(style)": { m: 1, width: "40ch" } }}
                noValidate
                autoComplete="off"
              >
                <TextField
                  id="outlined-basic"
                  label="Name"
                  variant="outlined"
                />

                <TextField
                  id="outlined-basic"
                  label="Email"
                  variant="outlined"
                />
                <TextField
                  id="outlined-basic"
                  label="Password"
                  variant="outlined"
                />
              </Box>
            </div>
            {/*  */}
            <div className="text-btn">
              <p className="register-p">
                Don't have an account{" "}
                <Link to="/register" className="register-login">
                  Register Here
                </Link>
              </p>
              <Link to="/">
                <button className="register-btn">Login</button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
