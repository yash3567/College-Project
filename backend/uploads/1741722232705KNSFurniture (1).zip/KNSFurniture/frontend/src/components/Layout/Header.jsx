import React from "react";
import { Link, NavLink } from "react-router-dom";

const Header = () => {
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary shadow p-3 mb-5 bg-body-tertiary rounded">
        <div className="container-fluid">
          <Link className="text-decoration-none" to="/">
            <h2 className="text-dark ">MAAN</h2>
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <NavLink className="text-decoration-none" to="/">
                  <a className="nav-link active" aria-current="page" href="#">
                    Home
                  </a>
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="text-decoration-none" to="/shop">
                  <a className="nav-link" href="#">
                    Shop
                  </a>
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="text-decoration-none" to="/about">
                  <a className="nav-link" href="#">
                    About
                  </a>
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="text-decoration-none" to="/contact">
                  <a className="nav-link " href="#">
                    Contact
                  </a>
                </NavLink>
              </li>
            </ul>
            {/* <div className="cart-btn">
              <NavLink to="/login">
                <button className="btn btn-primary">Cart</button>
              </NavLink>
            </div> */}
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Header;
