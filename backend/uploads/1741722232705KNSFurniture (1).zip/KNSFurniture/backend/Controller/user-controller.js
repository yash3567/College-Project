const users = require("../Models/user-Schema");
// Reguster Page Data k Liye use krreh hai
const HandleRegisterPage = async (req, res) => {
  const { name, email, password } = req.body;
  try {
    // first check honga koi field empty to nhi hai
    // if (!name || !email || !password) {
    //   res.send({ success: false, message: "Invalid User" });
    // }
    // second condition hai ki koi user already exist to nhi krta hai
    const existingUser = await users.findOne({ email });
    if (existingUser) {
      return res.send({
        success: false,
        message: "User Already Exists",
      });
    }

    // Dono condition check krne k bad me
    // user create honga or us ki value database me milegi,or response milega successfully register ka
    const user = await users.create({
      name,
      email,
      password,
    });
    res.send({
      success: true,
      message: "register Successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.send({ success: false, message: "Failed To register", error });
  }
};
//Ye jayega auth router vali file me
module.exports = { HandleRegisterPage };
