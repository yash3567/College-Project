const express = require("express");
const mongoose = require("mongoose");
// const hompageData = require("./homepage_api.json");
const cors = require("cors");
const HomeRouter = require("./Routes/homepage");
const ShopRouter = require("./Routes/shopPage");
const UserRouter = require("./Routes/auth");
const app = express();
const PORT = 5000;
const { connectMongoDB } = require("./Utils/connection"); //mongodb connection
//
// !!!!!!!!! pele bodyParser ka use krte thai jisse user se data le paye jo ki ab khtm hogya deprocaded, ap express.json ko use krte

// express.urlencoded ko use krnahi kuki vhi se send krre hai isiliye
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

//########################################################################
app.use(cors({ origin: "http://localhost:5173" }));
// *********#########mongodb connection ######****************
connectMongoDB(
  "mongodb+srv://Ksnfurniture:manthan123@ksnfurniture.geqrr.mongodb.net/KSN"
)
  .then(() => {
    console.log("MongoDb is Connected ");
  })
  .catch((error) => {
    console.log(error);
  });

app.use("/api", HomeRouter);
app.use("/api", ShopRouter);
app.use("/api/auth", UserRouter);
app.listen(PORT, () => {
  console.log(`Server is Running on ${PORT}`);
});
