const Router = require("express").Router();
const { HandleRegisterPage } = require("../Controller/user-controller");
Router.post("/register", HandleRegisterPage);
module.exports = Router;
